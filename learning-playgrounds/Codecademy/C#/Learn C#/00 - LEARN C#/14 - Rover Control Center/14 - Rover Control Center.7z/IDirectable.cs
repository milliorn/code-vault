namespace RoverControlCenter
{
  interface IDirectable
  {
    //Define an interface IDirectable with methods:
    string GetInfo();
    string Explore();
    string Collect();  
  }
}
