namespace RoverControlCenter
{
  class Probe
  {
    
  }
}
