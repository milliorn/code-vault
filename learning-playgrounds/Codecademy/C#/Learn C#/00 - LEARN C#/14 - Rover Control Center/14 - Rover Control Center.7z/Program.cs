using System;

namespace RoverControlCenter
{
  class Program
  {
    static void Main(string[] args)
    {
      MoonRover lunokhod = new MoonRover("Lunokhod 1", 1970);
      MoonRover apollo = new MoonRover("Apollo 15", 1971);
      MarsRover sojourner = new MarsRover("Sojourner", 1997);
      Satellite sputnik = new Satellite("Sputnik", 1957); 
  		
      //Store the three rovers in an array of type Rover[], their shared base class.
      Rover[] rover = { lunokhod, apollo, sojourner };
      
      //Call the DirectAll() method using the array as the argument.
      //DirectAll(rover);
      
      //To manage all space probes put them in an array.
      Object[] probes = { lunokhod, apollo, sojourner, sputnik };
      
      //Space out log so it is legible
      Console.WriteLine("");      
      //Test that we built Object[] correctly. 
      foreach(Object e in probes)
      {
        //Print the results of GetType() for each object in the array.
        Console.WriteLine($"Tracking a {e.GetType()}...");
      }
      
      //Create an array of type IDirectable[] containing all the probes.
      IDirectable[] directable = { lunokhod, apollo, sojourner, sputnik };
      
      //Space out log so it is legible
      Console.WriteLine("");   
      
      //Update DirectAll() method so it now accepts one argument of type IDirectable[].
      DirectAll(directable);
    }
    
    //Write a static method that takes one argument. 
    //Method should call three methods for each element.
    public static void DirectAll(IDirectable[] r)
    {
      foreach (IDirectable e in r)
      {
        //Print out the returned strings.
        Console.WriteLine(e.GetInfo());
        Console.WriteLine(e.Explore());
        Console.WriteLine(e.Collect());
      }
    }
  }
}
