// Define IResetable in this file

using System;

namespace SavingInterface
{
  interface IResetable
  {
    //define an interface with one method it should return nothing
    void Reset();
  }
}
