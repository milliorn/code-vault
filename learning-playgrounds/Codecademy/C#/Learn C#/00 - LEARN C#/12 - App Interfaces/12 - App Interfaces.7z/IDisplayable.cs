// Define IDisplayable in this file

using System;

namespace SavingInterface
{
  interface IDisplayable
  {
    //Within IDisplayable declare one method that returns nothing
    void Display();

  }
}
