using System;

namespace SavingInterface
{
  class PasswordManager : IDisplayable, IResetable
  {
    string password;
    private string Password
    { 
      get 
      { 
        return password; 
      }
      set 
      {
        if (value.Length >= 8)
        {
          password = value;
        }
      }
    }

    public bool Hidden { get; private set; }

    public PasswordManager(string password, bool hidden)
    {
      Password = password;
      Hidden = hidden;
    }
    //Define a method that satisfies the interface requirements
    public void Display()
    {
      if (Hidden)
      {
        Console.WriteLine("*****");
      }
      else
      {
      Console.WriteLine(Password);
      }
    }
    //Define a method to satisfy the interface.
    public void Reset()
    {
      Password = "";
      Hidden = false;    
    }
    //Add a method ChangePassword() with two string parameters
    public bool ChangePassword(string oldPass, string newPass)
    {
      //if the first argument matches Password
      if (oldPass == Password)
      {
        //Reset Password to second argument
        Password = newPass;
      }
      //return true if password change success(first argument matched old password)
      return oldPass == newPass;
    }
  }
}



