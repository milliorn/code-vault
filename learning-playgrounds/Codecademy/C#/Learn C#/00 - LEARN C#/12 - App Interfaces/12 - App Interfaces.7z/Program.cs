using System;

namespace SavingInterface
{
  class Program
  {
    static void Main(string[] args)
    {
      TodoList tdl = new TodoList();
      tdl.Add("Invite friends");
      tdl.Add("Buy decorations");
      tdl.Add("Party");

      PasswordManager pm = new PasswordManager("iluvpie", true);
      
      //Make sure that both classes are printable, call Display() on tdl and pm.
      //tdl.Display();
      //pm.Display();
      //Call Reset() and Display() with tdl and pm. In other words, both objects should display, then reset, then display again.
      tdl.Display();
      tdl.Reset();
      tdl.Display();

      pm.Display();
      pm.Reset();
      pm.Display();
    }
  }
}

