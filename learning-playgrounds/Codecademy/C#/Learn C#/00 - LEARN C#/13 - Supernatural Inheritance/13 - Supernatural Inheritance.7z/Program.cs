using System;

namespace MagicalInheritance
{
  class Program
  {
    static void Main(string[] args)
    {
      //Test your class! In Program.cs in Main(), construct a new Storm.
      Storm s = new Storm("wind", false, "Zul'rajas");
      //After constructing the new object, call Announce() and print console.
      Console.WriteLine(s.Announce());
      
      //Construct a new Pupil named Mezil-kree.
      Pupil p = new Pupil("Mezil-kree", "Icecrown");
      //Call CastWindStorm() and store in a variable.
      var Storm = p.CastWindStorm();
      // Use Announce() to check that it's a weak wind storm.
      Console.WriteLine(Storm.Announce());
      
      //Construct a new Mage named Gul’dan.
      Mage m = new Mage("Gul'dan", "Draenor");
      //Call CastRainStorm() and store in a variable. 
      var Rain = m.CastRainStorm();
      //Use Announce() to check that it is a weak rain storm.
      Console.WriteLine(Rain.Announce());
      
      //Construct a new Archmage named Nielas Aran.
      Archmage a = new Archmage("Nielas Aran", "Stormwind");
      //call CastRainStorm() and CastLightningStorm()
      var ArchRain = a.CastRainStorm();
      var Lightning = a.CastLightningStorm();
      //Use Announce() to make sure they are correct.
      Console.WriteLine(ArchRain.Announce());
      Console.WriteLine(Lightning.Announce());
      
      //Space out for step 19
      Console.WriteLine("");
      //Store the Storm objects in an array instead of separate variables.
      string[] final = { s.Announce(), p.CastWindStorm().Announce(), m.CastRainStorm().Announce(), a.CastRainStorm().Announce(),  a.CastLightningStorm().Announce() };
      
      foreach (string st in final)
      {
        Console.WriteLine(st);
      }
    }
  }
}



