// Pupil.cs
using System;

namespace MagicalInheritance
{
  public class Pupil
  {
    public string Title { get; private set; }
    //Add a string Origin property and a new constructor to the Pupil class. The constructor should have two parameters.
    public string Origin { get; private set; }
   //Constructor with one argument, that sets the Title property 
    public Pupil(string title, string origin)
    {
      Title = title;
      Origin = origin;
    }
    //Give the Pupil its single spell: CastWindStorm() Public, return type Storm. In the body of the method, construct a new Storm object and return it.
    public Storm CastWindStorm()
    {
      Storm s = new Storm("wind", false, Title);
      return s;
    }
  }
}

