// Spell.cs
using System;

namespace MagicalInheritance
{
  public abstract class Spell
  {
    //Define an abstract class Spell and an abstract Announce() method.
    public abstract string Announce();  
  }
}
