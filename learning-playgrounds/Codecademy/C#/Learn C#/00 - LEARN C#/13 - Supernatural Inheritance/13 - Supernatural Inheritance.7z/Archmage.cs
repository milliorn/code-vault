// Archmage.cs
using System;

namespace MagicalInheritance
{
  public class Archmage : Mage
  {
    public Archmage(string Title, string Origin) : base(Title, Origin) {}
    //Override CastRainStorm().  It should be public with return type Storm. In the body of the method, construct a new Storm object and return it.
    public override Storm CastRainStorm()
    {
      Storm s = new Storm("rain", true, Title);
      return s;
    }
    //Add CastLightningStorm(), public, return type Storm. In the body of the method, construct a new Storm object and return it.
   public Storm CastLightningStorm()
   {
     Storm s = new Storm("lightning", true, Title);
     return s;
   }
  }
}

