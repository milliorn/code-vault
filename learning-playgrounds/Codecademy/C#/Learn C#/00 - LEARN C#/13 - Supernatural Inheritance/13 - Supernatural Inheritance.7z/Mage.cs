// Mage.cs
using System;

namespace MagicalInheritance
{
  public class Mage : Pupil
  {
    public Mage(string Title, string Origin) : base(Title, Origin) {}
    //Give the Mage a new spell: CastRainStorm().  Set to public and return type Storm. In the body of the method, construct a new Storm object and return it.  
    //Since the CastRainStorm() method is overridden, it must be marked virtual.
    public virtual Storm CastRainStorm()
    {
      //Construct a new Storm object and return it.
      Storm s = new Storm("rain", false, Title);
      return s;
    }
  }
}
