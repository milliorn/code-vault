// Storm.cs
using System;

namespace MagicalInheritance
{
  public class Storm : Spell
  {
    //Define three automatic properties each with public getter and private setter
    public string Essence { get; private set; }
    public bool IsStrong { get; private set; }
    public string Caster { get; private set;}
    
    //Define a constructor that takes three arguments, one for each property.
    public Storm(string essence, bool isstrong, string caster)
    {
      //In the body of the constructor, use those arguments to set the property values
      Essence = essence;
      IsStrong = isstrong;
      Caster = caster;
    }
    //Define a method that returns a string. The string should use all three properties
    public override string Announce()
    {
      string a = IsStrong == true ? "strong" : "weak";
      return $"{Caster} cast a {a} {Essence}!";
    }
  }
}

